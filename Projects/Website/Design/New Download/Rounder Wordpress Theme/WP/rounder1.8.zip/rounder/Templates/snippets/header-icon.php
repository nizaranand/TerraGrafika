<div class="mwrap">
	<div class="molecule">
		<div class="p1wrap"><span class="particle1">&nbsp;</span></div>
		<div class="p2wrap"><span class="particle2">&nbsp;</span></div>
		<div class="p3wrap"><span class="particle3">&nbsp;</span></div>
	</div>
	<img src="{!$headerIcon}" alt="ico" width="65" height="65" class="ico">
</div>