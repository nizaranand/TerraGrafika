<span class="entry-date-comments">
	<a href="{dayLink $post->date}" class="clearfix">
	<span class="date-box">
		<span class="date">{$post->date|date:'%d'} {$post->date|date:'%b'}</span>
	</span>
	</a>

</span>
