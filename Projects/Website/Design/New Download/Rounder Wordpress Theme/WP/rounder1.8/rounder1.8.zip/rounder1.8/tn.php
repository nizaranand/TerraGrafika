<?php
/*
Just shortcut for timthumb.php
In templates use macro {timthumb src => ..., w => ..., h => ...}
 */
require_once dirname(__FILE__) . '/AIT/Framework/Libs/timthumb/timthumb.php';