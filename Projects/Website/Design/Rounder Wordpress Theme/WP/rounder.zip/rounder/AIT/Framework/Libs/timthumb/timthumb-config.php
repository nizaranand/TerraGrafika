<?php

define ('BLOCK_EXTERNAL_LEECHERS', true);
define ('ALLOW_EXTERNAL', true);
define ('FILE_CACHE_DIRECTORY', dirname(__FILE__) . '/../../../../ait-cache/timthumb');
$ALLOWED_SITES = array (
	'flickr.com',
	'staticflickr.com',
	'picasa.com',
	'img.youtube.com',
	'upload.wikimedia.org',
	'photobucket.com',
	'imgur.com',
	'imageshack.us',
	'tinypic.com',
	'preview.ait-themes.com'
);