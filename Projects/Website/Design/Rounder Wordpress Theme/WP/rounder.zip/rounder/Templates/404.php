{extends $layout}

{block content}

<section class="section content-section">

	<div id="container" class="subpage blog 404 clearfix">

		<div id="content" class="entry-content" role="main">
			<div class="content-wrapper">
				{include snippets/nothing-found.php}
			</div> <!-- /.content-wrapper -->
		</div> <!-- /#content -->

	</div> <!-- /#container -->

	<div class="rule-double">&nbsp;</div>

</section>

{/block}