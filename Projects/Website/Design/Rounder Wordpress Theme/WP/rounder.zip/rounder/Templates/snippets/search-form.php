<form action="{$homeUrl}" id="search-form" method="get" class="searchform">
	<div>

		<input type="submit" name="submit"  value="{__ 'Search'}" class="searchsubmit">
		<input type="text" name="s" placeholder="{__ 'search...'}" class="searchinput">

	</div>
</form>

